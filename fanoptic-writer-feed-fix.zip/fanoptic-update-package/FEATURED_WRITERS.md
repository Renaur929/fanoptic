# Featured writer picks

`public/featured-writers.json` is the curated source for the Top 3 profiles shown by the Local/Beat Writers and Independent Writers source filters. Each list is ordered by FanOptic's editorial picks, not by popularity. The interface displays at most three profiles for the selected filter.

For Local/Beat Writers, a card is shown only when FanOptic has reviewed the writer's identity and current reporting, and the profile has a real published photo. Set `verified` to `true` only after checking the writer's publication page or a reliable professional profile. A generic avatar, initials, or an unverified byline is not enough. If fewer than three writers meet both requirements for a selected team or league, show fewer than three. Do not fill the row with guesses.

For Independent Writers, confirm the writer's profile or publication page, original reporting, recent coverage for the team and sport, and a distinct voice or outlet where possible. Review the lists periodically and remove or replace inactive writers.

Each profile should use this shape:

```json
{
  "name": "Writer name",
  "label": "Broncos beat writer",
  "team": "Denver Broncos",
  "league": "NFL",
  "profileUrl": "https://publisher.example/writer",
  "photoUrl": "https://publisher.example/writer-photo.jpg",
  "verified": true,
  "lastReviewedAt": "2026-10-29"
}
```

For Local/Beat Writers, both `photoUrl` and `verified: true` are required. Use the writer's actual photo, not a generic avatar. Both the image and name link directly to `profileUrl`. Keep the registry empty until picks have been reviewed; do not add placeholder writers as if they were real people.
